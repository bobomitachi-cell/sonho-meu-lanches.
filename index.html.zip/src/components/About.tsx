import { Clock, MapPin, Phone } from "lucide-react";

export default function About() {
  return (
    <section id="sobre" className="py-16 bg-red-100">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-red-800 mb-12">
          Sobre Nós
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-md text-center border-2 border-red-200">
            <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-red-800 mb-2">Horário</h3>
            <p className="text-slate-600">Terça a Domingo</p>
            <p className="text-slate-600 font-semibold">18h às 23h</p>
          </div>
          
          <div className="bg-white p-8 rounded-2xl shadow-md text-center border-2 border-red-200">
            <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-red-800 mb-2">Localização</h3>
            <p className="text-slate-600">Rua Atravessa B.110</p>
            <p className="text-slate-600">Jardim Floresta</p>
          </div>
          
          <div className="bg-white p-8 rounded-2xl shadow-md text-center border-2 border-red-200">
            <div className="bg-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Phone className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-red-800 mb-2">Contato</h3>
            <p className="text-slate-600">(95) 99174-4484</p>
            <p className="text-slate-600">@sonhomeulance</p>
          </div>
        </div>
      </div>
    </section>
  );
}