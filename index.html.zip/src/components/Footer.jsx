import React from 'react'
import { MapPin, Clock, Phone, Mail } from 'lucide-react'

function Footer() {
  return (
    <footer id="contato" className="bg-red-900 py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Logo & Description */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-red-800 font-display text-xl">SM</span>
              </div>
              <span className="font-display text-xl text-white tracking-wider">
                SONHO MEULANCE
              </span>
            </div>
            <p className="text-red-200 text-sm">
              Hambúrgueres artesanais feitos com amor e ingredientes selecionados.
            </p>
          </div>

          {/* Address */}
          <div>
            <h4 className="font-display text-lg text-white mb-4">ENDEREÇO</h4>
            <div className="flex items-start gap-2 text-red-200 text-sm">
              <MapPin className="text-yellow-400 mt-1" size={18} />
              <p>Rua Atravessa B.110<br />Jardim Floresta</p>
            </div>
          </div>

          {/* Hours */}
          <div>
            <h4 className="font-display text-lg text-white mb-4">HORÁRIO</h4>
            <div className="flex items-start gap-2 text-red-200 text-sm">
              <Clock className="text-yellow-400 mt-1" size={18} />
              <div>
                <p>Terça a Domingo</p>
                <p>18:00 - 23:00</p>
              </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-lg text-white mb-4">CONTATO</h4>
            <div className="space-y-2">
              <a 
                href="https://wa.me/5511999999999"
                className="flex items-center gap-2 text-red-200 text-sm hover:text-yellow-400 transition"
              >
                <Phone className="text-yellow-400" size={18} />
                (11) 99999-9999
              </a>
              <a 
                href="mailto:contato@sonhomeulance.com"
                className="flex items-center gap-2 text-red-200 text-sm hover:text-yellow-400 transition"
              >
                <Mail className="text-yellow-400" size={18} />
                contato@sonhomeulance.com
              </a>
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-red-700 pt-8 text-center">
          <p className="text-red-300 text-sm">
            © 2024 Sonho Meulance. Todos os direitos reservados.
          </p>
          <p className="text-red-400 text-xs mt-2">
            Feito com ❤️ para você
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer