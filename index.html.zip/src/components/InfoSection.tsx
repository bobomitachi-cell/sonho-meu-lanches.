import { MapPin, Clock, Phone, CreditCard } from "lucide-react";

export function InfoSection() {
  return (
    <section className="mt-12 bg-white rounded-2xl shadow-lg p-6 border-2 border-orange-100">
      <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <span className="text-2xl">📍</span> Informações
      </h2>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-xl">
          <MapPin className="w-5 h-5 text-orange-600 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-800">Endereço</p>
            <p className="text-gray-600 text-sm">
              Rua Atravessa B.110 - Jd Floresta
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-xl">
          <Clock className="w-5 h-5 text-orange-600 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-800">Horário</p>
            <p className="text-gray-600 text-sm">Segunda a Sexta: 17h-22h</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-xl">
          <Phone className="w-5 h-5 text-orange-600 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-800">WhatsApp</p>
            <p className="text-gray-600 text-sm">(95) 99174-4484</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-xl">
          <CreditCard className="w-5 h-5 text-orange-600 mt-0.5" />
          <div>
            <p className="font-semibold text-gray-800">Pagamento</p>
            <p className="text-gray-600 text-sm">PIX, Cartão ou Dinheiro</p>
          </div>
        </div>
      </div>
    </section>
  );
}