import React, { useState } from 'react'
import { Menu as MenuIcon, X } from 'lucide-react'

function Header() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="bg-red-800 sticky top-0 z-50 shadow-lg">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center">
              <span className="text-red-800 font-display text-xl">SM</span>
            </div>
            <span className="font-display text-2xl text-white tracking-wider">
              SONHO MEULANCE
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#inicio" className="text-white hover:text-yellow-400 transition font-medium">Início</a>
            <a href="#cardapio" className="text-white hover:text-yellow-400 transition font-medium">Cardápio</a>
            <a href="#sobre" className="text-white hover:text-yellow-400 transition font-medium">Sobre</a>
            <a href="#contato" className="text-white hover:text-yellow-400 transition font-medium">Contato</a>
          </nav>

          {/* Mobile Button */}
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-white"
          >
            {isOpen ? <X size={28} /> : <MenuIcon size={28} />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-red-600 pt-4">
            <div className="flex flex-col gap-4">
              <a href="#inicio" className="text-white hover:text-yellow-400 transition font-medium">Início</a>
              <a href="#cardapio" className="text-white hover:text-yellow-400 transition font-medium">Cardápio</a>
              <a href="#sobre" className="text-white hover:text-yellow-400 transition font-medium">Sobre</a>
              <a href="#contato" className="text-white hover:text-yellow-400 transition font-medium">Contato</a>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Header