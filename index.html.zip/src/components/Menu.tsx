import { Button } from "./ui/button";

interface MenuProps {
  addToCart: () => void;
}

const menuItems = [
  {
    name: "Classic Burger",
    description: "Pão brioche, carne 180g, queijo cheddar, alface, tomate e molho especial",
    price: "R$ 28,90",
    image: "🍔"
  },
  {
    name: "Bacon Explosion",
    description: "Pão australiano, carne 200g, bacon crocante, queijo, cebola caramelizada",
    price: "R$ 34,90",
    image: "🥓"
  }
];

export default function Menu({ addToCart }: MenuProps) {
  return (
    <section id="menu" className="py-16 bg-red-700">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
          Nosso Cardápio
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {menuItems.map((item, index) => (
            <div 
              key={index}
              className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-shadow border-2 border-yellow-500"
            >
              <div className="text-5xl mb-4 text-center">{item.image}</div>
              <h3 className="text-xl font-bold text-red-800 mb-2">{item.name}</h3>
              <p className="text-slate-600 text-sm mb-4">{item.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-red-600 font-bold text-lg">{item.price}</span>
                <Button 
                  onClick={addToCart}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Adicionar
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}