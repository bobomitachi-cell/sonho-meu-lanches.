import { useState } from "react";
import { Button } from "../components/ui/button";
import { MenuItem } from "../types";
import { Clock, MessageCircle, ShoppingCart, Trash2, Phone } from "lucide-react";

interface CartProps {
  items: MenuItem[];
  removeFromCart: (index: number) => void;
  getTotal: () => number;
}

export function Cart({ items, removeFromCart, getTotal }: CartProps) {
  const [paymentMethod, setPaymentMethod] = useState<string>("pix");

  if (items.length === 0) {
    return (
      <div className="bg-slate-800 rounded-2xl p-8 text-center border-2 border-red-500">
        <ShoppingCart className="w-16 h-16 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400 font-medium text-lg">Carrinho vazio</p>
        <p className="text-slate-500 text-sm mt-1">Adicione lanches! 🍔</p>
      </div>
    );
  }

  const handleOrder = () => {
    const orderText = items.map((item) => `• ${item.name}`).join("\n");
    const total = getTotal();
    const message = `🍔 *Novo Pedido - Sonho Meu!*

${orderText}

💰 *Total:* R$ ${total},00
💳 *Pagamento:* ${paymentMethod.toUpperCase()}

Obrigado! 🙏`;

    const whatsappUrl = `https://wa.me/5595991744484?text=${encodeURIComponent(
      message
    )}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <section className="bg-slate-800 rounded-2xl p-5 border-2 border-red-500 sticky top-4 shadow-xl">
      <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
        <ShoppingCart className="w-5 h-5 text-red-400" />
        Seu Pedido
        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
          {items.length}
        </span>
      </h2>

      <div className="space-y-2 mb-4 max-h-48 overflow-y-auto">
        {items.map((item, index) => (
          <div
            key={index}
            className="flex justify-between items-center bg-slate-700 p-3 rounded-xl group"
          >
            <div className="flex items-center gap-3">
              <img 
                src={item.image} 
                alt={item.name}
                className="w-12 h-12 rounded-lg object-cover border-2 border-red-500"
              />
              <span className="font-medium text-white">{item.name}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-red-400">
                R$ {item.price},00
              </span>
              <button
                onClick={() => removeFromCart(index)}
                className="text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t-2 border-slate-700 pt-4 mb-4">
        <div className="flex justify-between items-center text-2xl font-black">
          <span className="text-white">Total:</span>
          <span className="text-red-400">R$ {getTotal()},00</span>
        </div>
        <div className="flex items-center gap-2 text-slate-400 mt-3 text-sm bg-slate-700 px-3 py-2 rounded-lg">
          <Clock className="w-4 h-4 text-red-400" />
          <span>Entrega: 45-60 min</span>
        </div>
      </div>

      <div className="mb-4">
        <p className="font-medium text-slate-300 mb-3 text-sm">Pagamento:</p>
        <div className="grid grid-cols-3 gap-2">
          {[
            { id: "pix", label: "PIX", icon: "💳" },
            { id: "cartao", label: "Cartão", icon: "💳" },
            { id: "dinheiro", label: "Dinheiro", icon: "💵" },
          ].map((method) => (
            <button
              key={method.id}
              onClick={() => setPaymentMethod(method.id)}
              className={`px-2 py-3 rounded-xl font-medium text-sm transition-all border-2 ${
                paymentMethod === method.id
                  ? "bg-red-500 text-white border-red-400 shadow-lg shadow-red-500/30"
                  : "bg-slate-700 text-slate-300 border-slate-600 hover:border-red-500/50"
              }`}
            >
              <span className="block text-xl mb-1">{method.icon}</span>
              {method.label}
            </button>
          ))}
        </div>
        {paymentMethod === "pix" && (
          <p className="text-xs text-slate-400 mt-3 bg-slate-700 p-3 rounded-lg">
            💡 PIX na hora do pedido
          </p>
        )}
        {(paymentMethod === "dinheiro" || paymentMethod === "cartao") && (
          <p className="text-xs text-slate-400 mt-3 bg-slate-700 p-3 rounded-lg">
            💡 Pagamento ao motoboy na entrega
          </p>
        )}
      </div>

      <Button
        onClick={handleOrder}
        className="w-full bg-green-600 hover:bg-green-500 text-white py-4 text-lg font-bold flex items-center justify-center gap-2 shadow-lg shadow-green-500/30 rounded-xl"
      >
        <MessageCircle className="w-5 h-5" />
        Enviar Pedido
      </Button>

      <div className="mt-4 pt-4 border-t-2 border-slate-700">
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <Phone className="w-4 h-4 text-red-400" />
          <span>(95) 99174-4484</span>
        </div>
      </div>
    </section>
  );
}