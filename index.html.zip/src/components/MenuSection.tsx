import { Button } from "../components/ui/button";
import { MenuItem } from "../types";
import { Plus } from "lucide-react";

const menuItems: MenuItem[] = [
  {
    id: "1",
    name: "X-Burguer",
    price: 32,
    description: "Pão de batata macio com hambúrguer suculento",
    ingredients: ["Pão de batata", "2 carnes", "Cheddar"],
    image: "https://images.unsplash.com/photo-1568901346375-23c391919029?w=400&h=300&fit=crop",
  },
  {
    id: "2",
    name: "X-Bacon",
    price: 38,
    description: "X-Burguer com bacon crocante extra",
    ingredients: ["Pão de batata", "2 carnes", "Cheddar", "Bacon"],
    image: "https://images.unsplash.com/photo-1553979459-222586d8bc19?w=400&h=300&fit=crop",
  },
];

interface MenuSectionProps {
  addToCart: (item: MenuItem) => void;
}

export function MenuSection({ addToCart }: MenuSectionProps) {
  return (
    <section>
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <span className="text-3xl">📋</span> Cardápio
      </h2>
      <div className="grid gap-6">
        {menuItems.map((item) => (
          <div
            key={item.id}
            className="bg-slate-800 rounded-2xl overflow-hidden border-2 border-red-500 hover:border-red-400 transition-all group shadow-xl"
          >
            <div className="flex flex-col sm:flex-row">
              <div className="w-full sm:w-52 h-52 sm:h-auto shrink-0 overflow-hidden relative">
                <img 
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-slate-800/50 sm:bg-gradient-to-r" />
              </div>
              <div className="p-6 flex-1">
                <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-3">
                  <h3 className="text-2xl font-bold text-white">{item.name}</h3>
                  <span className="text-3xl font-black text-red-400 whitespace-nowrap">
                    R$ {item.price},00
                  </span>
                </div>
                <p className="text-slate-400 mb-4">{item.description}</p>
                <div className="flex flex-wrap gap-2 mb-5">
                  {item.ingredients.map((ing, i) => (
                    <span
                      key={i}
                      className="bg-slate-700 text-slate-300 text-sm px-3 py-1 rounded-full border border-red-500/30"
                    >
                      {ing}
                    </span>
                  ))}
                </div>
                <Button
                  onClick={() => addToCart(item)}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold flex items-center gap-2 shadow-lg shadow-red-500/30"
                >
                  <Plus className="w-5 h-5" />
                  Adicionar
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}