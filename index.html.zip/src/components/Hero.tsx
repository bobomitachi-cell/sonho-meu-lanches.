import { Truck, Clock } from "lucide-react";

export function Hero() {
  return (
    <section className="py-16 px-4 bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center gap-12">
          {/* Foto */}
          <div className="w-72 h-72 shrink-0 overflow-hidden border-4 border-red-500 shadow-2xl shadow-red-500/50">
            <img 
              src="https://i.ibb.co/BKnhDSvx/Chat-GPT-Image-3-de-mai-de-2026-20-45-32.png"
              alt="Sonho Meu Lanches"
              className="w-full h-full object-cover object-center"
              style={{ objectFit: 'cover', objectPosition: '50% 50%', transform: 'scaleX(1.08)' }}
            />
          </div>
          
          {/* Texto ao lado */}
          <div className="text-center md:text-left flex-1">
            <h2 className="text-4xl md:text-6xl font-black text-white mb-4">
              Sonho Meu Lanches
            </h2>
            <p className="text-xl text-red-400 mb-2 italic">
              "Onde cada lanche é feito com amor de vó"
            </p>
            <p className="text-lg text-slate-400 mb-8 max-w-xl">
              Pão de batata artesanal, hambúrguer suculento e muito cheddar derretido
            </p>
            
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <div className="flex items-center gap-2 bg-slate-800 text-white px-5 py-3 rounded-xl border-2 border-red-500">
                <Truck className="w-5 h-5 text-red-400" />
                <span className="font-medium">Só Delivery</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-800 text-white px-5 py-3 rounded-xl border-2 border-red-500">
                <Clock className="w-5 h-5 text-red-400" />
                <span className="font-medium">45-60 min</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}