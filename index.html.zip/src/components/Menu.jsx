import React, { useState } from 'react'
import { Star } from 'lucide-react'

const menuItems = [
  {
    id: 1,
    name: "Classic Burger",
    description: "Pão brioche, 180g de blend bovino, queijo cheddar, alface, tomate e molho especial",
    price: 28.90,
    category: "burgers",
    featured: true
  },
  {
    id: 2,
    name: "Bacon Supreme",
    description: "Pão australiano, 200g de blend, bacon crocante, cheddar duplo, cebola caramelizada",
    price: 34.90,
    category: "burgers",
    featured: true
  },
  {
    id: 3,
    name: "Chicken Crispy",
    description: "Pão com gergelim, filé de frango empanado, maionese de ervas, alface e tomate",
    price: 26.90,
    category: "burgers",
    featured: false
  },
  {
    id: 4,
    name: "Veggie Burger",
    description: "Pão integral, hambúrguer de grão de bico, rúcula, tomate seco e molho tahine",
    price: 29.90,
    category: "burgers",
    featured: false
  },
  {
    id: 5,
    name: "Batata Frita",
    description: "Porção generosa de batatas fritas crocantes com tempero especial da casa",
    price: 15.90,
    category: "sides",
    featured: false
  },
  {
    id: 6,
    name: "Onion Rings",
    description: "Anéis de cebola empanados e fritos, servidos com molho barbecue",
    price: 18.90,
    category: "sides",
    featured: false
  },
  {
    id: 7,
    name: "Refrigerante Lata",
    description: "Coca-Cola, Guaraná Antarctica, Sprite ou Fanta Laranja",
    price: 6.90,
    category: "drinks",
    featured: false
  },
  {
    id: 8,
    name: "Suco Natural",
    description: "Suco de laranja, limão ou maracujá feito na hora - 400ml",
    price: 10.90,
    category: "drinks",
    featured: false
  }
]

const categories = [
  { id: "all", name: "Todos" },
  { id: "burgers", name: "Hambúrgueres" },
  { id: "sides", name: "Acompanhamentos" },
  { id: "drinks", name: "Bebidas" }
]

function Menu() {
  const [activeCategory, setActiveCategory] = useState("all")

  const filteredItems = activeCategory === "all" 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory)

  return (
    <section id="cardapio" className="bg-red-700 py-16">
      <div className="max-w-6xl mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="font-display text-4xl md:text-5xl text-white mb-4">
            NOSSO CARDÁPIO
          </h2>
          <p className="text-red-100 max-w-xl mx-auto">
            Feitos com ingredientes frescos e muito carinho. Escolha seu favorito!
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-6 py-2 rounded-full font-medium transition ${
                activeCategory === cat.id
                  ? "bg-yellow-400 text-red-800"
                  : "bg-red-800 text-white hover:bg-red-600"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Menu Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => (
            <div 
              key={item.id}
              className="bg-red-800 rounded-xl p-6 hover:bg-red-600 transition transform hover:scale-105 shadow-lg relative"
            >
              {item.featured && (
                <div className="absolute -top-2 -right-2 bg-yellow-400 text-red-800 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                  <Star size={12} /> DESTAQUE
                </div>
              )}
              
              <h3 className="font-display text-2xl text-white mb-2">
                {item.name}
              </h3>
              <p className="text-red-200 text-sm mb-4">
                {item.description}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-yellow-400 font-bold text-2xl">
                  R$ {item.price.toFixed(2).replace(".", ",")}
                </span>
                <a 
                  href="https://wa.me/5511999999999?text=Olá! Quero pedir: ${item.name}"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-500 hover:bg-green-400 text-white px-4 py-2 rounded-lg text-sm font-semibold transition"
                >
                  Pedir
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Menu