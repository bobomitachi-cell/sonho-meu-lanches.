import React from 'react'
import { Heart, Flame, Users } from 'lucide-react'

function About() {
  return (
    <section id="sobre" className="bg-red-800 py-16">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-display text-4xl md:text-5xl text-white mb-4">
            NOSSA HISTÓRIA
          </h2>
          <p className="text-red-100 max-w-2xl mx-auto">
            Mais do que hambúrgueres, entregamos momentos de felicidade para você e sua família.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Card 1 */}
          <div className="bg-red-700 rounded-xl p-8 text-center hover:bg-red-600 transition">
            <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="text-red-800" size={32} />
            </div>
            <h3 className="font-display text-2xl text-white mb-4">
              FEITO COM AMOR
            </h3>
            <p className="text-red-100">
              Cada hambúrguer é preparado com carinho e dedicação, usando receitas desenvolvidas com muito amor.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-red-700 rounded-xl p-8 text-center hover:bg-red-600 transition">
            <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <Flame className="text-red-800" size={32} />
            </div>
            <h3 className="font-display text-2xl text-white mb-4">
              INGREDIENTES FRESCOS
            </h3>
            <p className="text-red-100">
              Trabalhamos apenas com ingredientes selecionados e frescos. Qualidade é nossa prioridade.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-red-700 rounded-xl p-8 text-center hover:bg-red-600 transition">
            <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="text-red-800" size={32} />
            </div>
            <h3 className="font-display text-2xl text-white mb-4">
              PARA TODA FAMÍLIA
            </h3>
            <p className="text-red-100">
              Um lugar acolhedor para reunir amigos e família. Venha conhecer nosso espaço!
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About