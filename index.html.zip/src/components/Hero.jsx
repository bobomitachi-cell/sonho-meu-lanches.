import React from 'react'
import { Clock, MapPin } from 'lucide-react'

function Hero() {
  return (
    <section id="inicio" className="bg-red-700 py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center">
          {/* Badge */}
          <div className="inline-block bg-yellow-400 text-red-800 px-4 py-1 rounded-full text-sm font-semibold mb-6">
            🔥 Hambúrgueres Artesanais
          </div>

          {/* Title */}
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl text-white mb-6 leading-tight">
            SONHO MEULANCE
          </h1>

          {/* Subtitle */}
          <p className="text-red-100 text-lg md:text-xl max-w-2xl mx-auto mb-8">
            Hambúrgueres artesanais feitos com ingredientes selecionados e muito amor. 
            Sabor que faz você sonhar!
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <a 
              href="#cardapio"
              className="bg-yellow-400 hover:bg-yellow-300 text-red-800 font-bold px-8 py-4 rounded-lg text-lg transition transform hover:scale-105 shadow-lg"
            >
              Ver Cardápio
            </a>
            <a 
              href="https://wa.me/5511999999999?text=Olá! Quero fazer um pedido!"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-500 hover:bg-green-400 text-white font-bold px-8 py-4 rounded-lg text-lg transition transform hover:scale-105 shadow-lg flex items-center justify-center gap-2"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.29.173-1.414-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.895c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Pedir pelo WhatsApp
            </a>
          </div>

          {/* Info Cards */}
          <div className="grid md:grid-cols-2 gap-4 max-w-xl mx-auto">
            <div className="bg-red-800 rounded-lg p-4 flex items-center gap-3">
              <MapPin className="text-yellow-400" size={24} />
              <div className="text-left">
                <p className="text-red-200 text-sm">Endereço</p>
                <p className="text-white font-medium">Rua Atravessa B.110 - Jardim Floresta</p>
              </div>
            </div>
            <div className="bg-red-800 rounded-lg p-4 flex items-center gap-3">
              <Clock className="text-yellow-400" size={24} />
              <div className="text-left">
                <p className="text-red-200 text-sm">Horário</p>
                <p className="text-white font-medium">Ter a Dom: 18h - 23h</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero