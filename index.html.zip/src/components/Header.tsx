import { Flame, Phone, Clock } from "lucide-react";

export function Header() {
  return (
    <header className="bg-slate-950 border-b-4 border-red-500">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-red-500 to-red-700 p-3 rounded-xl shadow-lg shadow-red-500/30">
              <Flame className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">
                Sonho Meu Lanches
              </h1>
              <p className="text-red-400 text-sm">Homenagem a Ermina Estefania</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 text-sm">
            <a
              href="https://wa.me/5595991744484"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-500 transition-colors shadow-lg"
            >
              <Phone className="w-4 h-4" />
              <span className="font-medium">(95) 99174-4484</span>
            </a>
            <div className="flex items-center gap-2 bg-slate-800 text-slate-300 px-4 py-2 rounded-full border-2 border-red-500">
              <Clock className="w-4 h-4 text-red-400" />
              <span>Seg-Sex 17h-22h</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}