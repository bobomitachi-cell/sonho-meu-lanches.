import { Flame, Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-slate-950 border-t-4 border-red-500 py-8 mt-8">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <Flame className="w-6 h-6 text-red-500" />
          <span className="text-xl font-bold text-white">Sonho Meu Lanches</span>
          <Heart className="w-5 h-5 text-red-500 fill-red-500" />
        </div>
        <p className="text-slate-400 text-sm mb-1">
          Homenagem a Ermina Estefania
        </p>
        <p className="text-slate-500 text-sm mb-4">
          Seg-Sex 17h-22h
        </p>
        <div className="flex justify-center gap-4 text-sm">
          <span className="bg-slate-800 text-slate-300 px-4 py-2 rounded-full border-2 border-red-500">
            🛵 Só Delivery
          </span>
          <a 
            href="https://wa.me/5595991744484" 
            target="_blank"
            rel="noopener noreferrer"
            className="bg-green-600 text-white px-4 py-2 rounded-full hover:bg-green-500 transition-colors"
          >
            📱 WhatsApp
          </a>
        </div>
        <p className="text-slate-600 text-xs mt-6">
          Feito com ❤️ em memória da vó Ermina Estefania
        </p>
      </div>
    </footer>
  );
}