import React from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import Menu from './components/Menu'
import About from './components/About'
import Footer from './components/Footer'

function App() {
  return (
    <div className="bg-red-700 min-h-screen">
      <Header />
      <Hero />
      <Menu />
      <About />
      <Footer />
    </div>
  )
}

export default App