import { useState } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { MenuSection } from "./components/MenuSection";
import { Cart } from "./components/Cart";
import { Footer } from "./components/Footer";
import { MenuItem } from "./types";

function App() {
  const [cartItems, setCartItems] = useState<MenuItem[]>([]);

  const addToCart = (item: MenuItem) => {
    setCartItems((prev) => [...prev, item]);
  };

  const removeFromCart = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const getTotal = () => {
    return cartItems.reduce((sum, item) => sum + item.price, 0);
  };

  return (
    <div className="min-h-screen bg-slate-900">
      <Header />
      <Hero />
      <main className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <MenuSection addToCart={addToCart} />
          </div>
          <div className="lg:col-span-1">
            <Cart
              items={cartItems}
              removeFromCart={removeFromCart}
              getTotal={getTotal}
            />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

export default App;