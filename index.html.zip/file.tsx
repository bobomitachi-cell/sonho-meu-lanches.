<img 
  src="COLE_O_LINK_AQUI"
  alt="Hambúrguer delicioso"
  className="w-72 h-72 md:w-96 md:h-96 object-cover rounded-full shadow-2xl border-4 border-amber-400"
/>